;                (function() {
                    window.require(["ace/snippets/html_ruby"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            