

<?php $__env->startPush('plugin-styles'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">Order Details</h4>
        </div>
    </div>   

    <div class="row">
        <div class="col-md-9 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Orders List</h6>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Player Name</th>
                                    <th>Player Email</th>
                                    <th>Player Phone</th>
                                    <th>Product Name</th>
                                    <th>Product Image</th>
                                    <th>Coins</th>
                                    <th>Status</th>                                    
                                </tr>
                            </thead>
                            <tbody>
                                
                              
                              <?php for($i = 0; $i < count($orderDetails); $i++): ?>
                              
                              <tr id="data<?php echo e($orderDetails[$i]['order_id']); ?>">
                                <th><?php echo e($orderDetails[$i]['order_id']); ?></th>
                                <td id="playername"><?php echo e($orderDetails[$i]['Player_name']); ?></td> 
                                <td id="playeremail"><?php echo e($orderDetails[$i]['Player_email']); ?></td> 
                                <td id="playerphone"><?php echo e($orderDetails[$i]['Player_phonenumber']); ?></td>
                                <td id="productname"><?php echo e($orderDetails[$i]['Product_name']); ?></td>                                 
                                <td id="productimage">
                                    <?php $img = $orderDetails[$i]['Product_image']; ?>
                                    <img src="<?php echo e(asset('images/'.$img)); ?>" />
                                </td> 
                                <td id="productname"><?php echo e($orderDetails[$i]['Product_coins']); ?></td>                               
                                <td>
                                    <div id="<?php echo e($orderDetails[$i]['order_id']); ?>" class="dropdown" onchange="statusupdate(event)">
                                        <select class="btn btn-secondary  dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <option class="dropdown-item" <?php echo e($orderDetails[$i]['order_status'] == "Pending" ? "selected" : ""); ?>  href="#">Pending</option>
                                            <option class="dropdown-item" <?php echo e($orderDetails[$i]['order_status'] == "Approved" ? "selected" : ""); ?> href="#">Approved</option>
                                            <option class="dropdown-item" <?php echo e($orderDetails[$i]['order_status'] == "Rejected" ? "selected" : ""); ?> href="#">Rejected</option>
                                        </select>                                     
                                      </div>
                                </td>
                                </tr>


                                <?php endfor; ?>
                                


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('assets/js/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datepicker.js')); ?>"></script>

    
     

    <script>
        function statusupdate(e){

         
            let token = document.querySelector('meta[name="csrf-token"]').content;
            let xhr = new XMLHttpRequest();
            let url = '<?php echo e(route('orders.update')); ?> ';

            let formData = new FormData();
            formData.append('status', e.target.value);
  
            formData.append('id', e.currentTarget.id);
           

            xhr.open("POST", url , true);
            xhr.setRequestHeader('X-CSRF-TOKEN', token);

            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    const data = JSON.parse(this.responseText);
                    location.reload();
                }
        };

        xhr.send(formData);



        }
        </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\code\MERN-QUIZ\abhishek-quiz\backend\resources\views/admin/order.blade.php ENDPATH**/ ?>