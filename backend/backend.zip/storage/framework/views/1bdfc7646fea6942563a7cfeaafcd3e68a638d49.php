<!DOCTYPE html>
<html>
<head>
    <title>Laravel 9 Send Email Example - XpertPhp</title>
</head>
<body>
    <div>
 <p><?php echo e($maildata['email']); ?></p>
 <p><?php echo e($maildata['message']); ?></p>
 <p><?php echo e($maildata['subject']); ?></p>
 <p>Thank you</p>
    </div>
</body>
</html><?php /**PATH R:\code\MERN-QUIZ\abhishek-quiz\backend\resources\views/emails/mySendMail.blade.php ENDPATH**/ ?>