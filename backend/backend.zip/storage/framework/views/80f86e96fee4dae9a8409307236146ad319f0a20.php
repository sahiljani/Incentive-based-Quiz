<?php
$Parsedown = new Parsedown();

?>




<?php $__env->startPush('plugin-styles'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<link href="<?php echo e(asset('assets/plugins/simplemde/simplemde.min.css')); ?>" rel="stylesheet" />

    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">CATEGORY</h4>
        </div>

    </div>
    <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-success">
                            <div><?php echo e(Session::get('message')); ?></div>
                        </div>
                    <?php endif; ?>


                    <h6 class="card-title"> Form</h6>



                    <form  action='<?php echo e(route('quiz.edit.store', [$quiz['id']])); ?>' method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <label for="exampleInputUsername2" class="col-sm-3 col-form-label">NAME</label>
                            <div class="col-sm-9">
                                <input
                                id="checkchar"

                                name="name" type="text" class="form-control"
                                 value="<?php echo e($quiz['name']); ?>"  placeholder="Enter Quiz Name...">
                            </div>
                        </div>


                        <div class="row mb-3">
                            <label for="exampleInputUsername2" class="col-sm-3 col-form-label">Instructions</label>
                            <textarea

                            value="<?php echo e($quiz['instruction']); ?>"
                            name="instructions" class="form-control" name="tinymce" id="simpleMdeExample" rows="10"><?php echo e($quiz['instruction']); ?></textarea>
                        </div>


                        <div class="row mb-3">

                            <?php
                            $quizimg  = $quiz['image'];
                            ?>
                            <img class="mb-5" src="<?php echo e(asset("images/$quizimg")); ?>" />

                            <label for="exampleInputUsername2" class="col-sm-3 col-form-label">Image</label>
                            <div class="col-sm-9">
                                <input name="image" type="file" class="form-control"
                                 value=""
                                    placeholder="Enter Category Name...">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="exampleInputUsername2" class="col-sm-3 col-form-label">Category</label>

                                <select name="category" class="form-select">

                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item['name']); ?>"

                                <?php echo e(( $item->name == $quiz['category']) ? 'selected' : ''); ?>

                                ><?php echo e($item['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>

                          </div>


                        <div class="row">
                            <div class="col-md-6">
                                <label for="exampleInputUsername2" class="col-form-label">COINS</label>
                            <div class="col-sm-9">
                                <input name="coins" type="number" class="form-control"
                                value="<?php echo e($quiz['coins']); ?>"
                                    placeholder="Enter Coins...">
                            </div>
                            </div>


                            <div class="col-md-6">
                                <label for="exampleInputUsername2" class=" col-form-label">CHARGES</label>
                            <div class="col-sm-9">
                                <input name="charges" type="number" class="form-control"
                                value="<?php echo e($quiz['charges']); ?>"
                                    placeholder="Enter Coins...">
                            </div>
                            </div>

                        </div>

                        <button type="submit" class="btn btn-primary me-2 mt-3">Submit</button>

                    </form>


                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/plugins/simplemde/simplemde.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('assets/js/dashboard.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/datepicker.js')); ?>"></script>

    <script>

$(function() {
  'use strict';

  /*simplemde editor*/
  if ($("#simpleMdeExample").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMdeExample")[0]
    });
  }

});
        function DeleteData(url) {

            let text = "Are you sure to delete this record? \nEither OK or Cancel.";
            if (confirm(text) == true) {


            console.log(url);

            let token = document.querySelector('meta[name="csrf-token"]').content;
            let xhr = new XMLHttpRequest();

            xhr.open("POST", url , true);

            xhr.setRequestHeader('X-CSRF-TOKEN', token);

            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    const data = JSON.parse(this.responseText);
                    location.reload();
                }
            };
            xhr.send();



        }
    }

    const eventTarget = document.querySelector('#checkchar');
    const name = document.querySelector('#name');
    if(typeof eventTarget !== undefined){
        eventTarget.addEventListener("keydown", FilterTitle);
    }

    if(typeof name !== undefined){
        name.addEventListener("keydown", FilterTitle);
    }
        function FilterTitle(e) {
            console.log( e.target.value);
           const str = e.target.value;
            const noSpecialCharacters = str.replace(/[^a-zA-Z0-9 ]/g, '');
            e.target.value = noSpecialCharacters;

    }
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\code\MERN-QUIZ\abhishek-quiz\backend\resources\views/admin/editQuiz.blade.php ENDPATH**/ ?>