<?php
$Parsedown = new Parsedown();
?>




<?php $__env->startPush('plugin-styles'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link href="<?php echo e(asset('assets/plugins/simplemde/simplemde.min.css')); ?>" rel="stylesheet" />

    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>



<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">

        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success">
                                <div><?php echo e(Session::get('message')); ?></div>
                            </div>
                        <?php endif; ?>


                        <h6 class="card-title">Form</h6>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <form action="<?php echo e(route('update.setting')); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="1" />
                          <div class="row">
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <label for="Logo" class="col-sm-3 col-form-label">Logo</label>
                                    <img class="" src="<?php echo e(asset("images/$item->logo")); ?>" style="max-width:600px; max-height:600px; width: 600px; height: 300px;" />
                                    <div class="col-sm-9">
                                        <input name="logo" type="file" class="form-control"
                                          placeholder="Upload Logo">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <label for="favicon" class="col-sm-3 col-form-label">favicon</label>
                                    <img class="" src="<?php echo e(asset("images/$item->favicon")); ?>"  style="width: 160px; height: 160px;" />                                    
                                    <div class="col-sm-9">
                                        <input name="favicon" type="file" class="form-control"
                                            placeholder="Upload Logo">
                                    </div>
                                </div>
                            </div>
                          </div>

                          <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="Title" class="form-label">Title</label>
                                <input name="title" value="<?php echo e($item->title); ?>"  type="text" class="form-control" id="Title" placeholder="Title....">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="metadescription" class="form-label">Meta description</label>
                                <input name="metadescription" value="<?php echo e($item->metadescription); ?>"  type="text" class="form-control" id="metadescription" placeholder="meta description...." required>
                            </div>
                          </div>

                          <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="metakeywords" class="form-label">Meta Keywords</label>
                                <input name="metakeywords" value="<?php echo e($item->metakeywords); ?>"  type="text" class="form-control" id="metakeywords" placeholder="Meta Keywords...." required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="metaogdescription" class="form-label">Meta og:description</label>
                                <input name="metaogdescription" value="<?php echo e($item->metaogdescription); ?>"  type="text" class="form-control" id="metaogdescription" placeholder="Enter meta og:description...." required>
                            </div>
                          </div>                          

                          <div class="row mb-3">                           
                            <div class="col-md-12 mb-3">
                                <label for="publisherid" class="form-label">Publisher ID</label>
                                <input name="publisherid" value="<?php echo e($item->publisherid); ?>"  type="text" class="form-control" id="publisherid" placeholder="publisher Id....">
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <div class="mb-3">
                                        <label for="Headerscript" class="form-label">Header Script</label>
                                        <textarea name="headerScript"
                                        class="form-control" id="Headerscript" rows="3"><?php echo e($item->headerScript); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <div class="mb-3">
                                        <label for="footerScript" class="form-label">Footer Script</label>
                                        <textarea name="footerScript"
                                        class="form-control" id="footerScript" rows="3"><?php echo e($item->footerScript); ?></textarea>
                                    </div>
                                </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <div class="mb-3">
                                        <label for="quizrules" class="form-label">Quiz Rules</label>
                                        <textarea name="quizrules" id="simpleMdeExample3"
                                        class="form-control" id="quizrules" rows="3"><?php echo e($item->quizrules); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <div class="mb-3">
                                        <label for="privacypolicy" class="form-label">Privacy Policy</label>
                                        <textarea name="privacypolicy" id="simpleMdeExample4"
                                        class="form-control" id="privacypolicy" rows="3"><?php echo e($item->privacypolicy); ?></textarea>
                                    </div>
                                </div>
                            </div>
                          </div>                          

                          <div class="row">
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <div class="row mb-3">
                                        <label for="exampleInputUsername2" 
                                        class="form-label">First Page Instructions</label>
                                        <textarea name="Firstpageinstructions" class="form-control" 
                                        name="tinymce"
                                        id="simpleMdeExample" rows="8"><?php echo e($item->Firstpageinstructions); ?></textarea>
                                    </div>
                                </div>
                            </div> 
                            
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <div class="row mb-3">
                                        <label for="exampleInputUsername2" 
                                        class="form-label">LoginPage Instructions</label>
                                        <textarea name="LoginPageinstructions" class="form-control" 
                                        name="tinymce"
                                        id="simpleMdeExample2" rows="8"><?php echo e($item->LoginPageinstructions); ?></textarea>
                                    </div>
                                </div>
                            </div> 
                          </div>                        

                        <button type="submit" class="btn btn-primary me-2">Submit</button>

                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/simplemde/simplemde.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('assets/js/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datepicker.js')); ?>"></script>



    
<script>

    $(function() {
        'use strict';
        /*simplemde editor*/
        if ($("#simpleMdeExample").length) {
            var simplemde = new SimpleMDE({
                toolbar: ["bold", "italic", "heading", "|", "unordered-list", "ordered-list", "|", "preview","fullscreen"],
                element: $("#simpleMdeExample")[0]
            });
        }

    });

    $(function() {
        'use strict';
        /*simplemde editor*/
        if ($("#simpleMdeExample2").length) {
            var simplemde = new SimpleMDE({
                toolbar: ["bold", "italic", "heading", "|", "unordered-list", "ordered-list", "|", "preview","fullscreen"],
                element: $("#simpleMdeExample2")[0]
            });
        }

    });


    $(function() {
        'use strict';
        /*simplemde editor*/
        if ($("#simpleMdeExample3").length) {
            var simplemde = new SimpleMDE({
                toolbar: ["bold", "italic", "heading", "|", "unordered-list", "ordered-list", "|", "preview","fullscreen"],
                element: $("#simpleMdeExample3")[0]
            });
        }

    });
    
    $(function() {
        'use strict';
        /*simplemde editor*/
        if ($("#simpleMdeExample4").length) {
            var simplemde = new SimpleMDE({
                toolbar: ["bold", "italic", "heading", "|", "unordered-list", "ordered-list", "|", "preview","fullscreen"],
                element: $("#simpleMdeExample4")[0]
            });
        }

    });

    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\code\MERN-QUIZ\abhishek-quiz\backend\resources\views/admin/setting.blade.php ENDPATH**/ ?>