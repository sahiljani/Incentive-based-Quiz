<?php
$Parsedown = new Parsedown();
?>




<?php $__env->startPush('plugin-styles'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link href="<?php echo e(asset('assets/plugins/simplemde/simplemde.min.css')); ?>" rel="stylesheet" />

    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">Add Quiz</h4>
        </div>

    </div>
    <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-success">
                            <div><?php echo e(Session::get('message')); ?></div>
                        </div>
                    <?php endif; ?>


                    <h6 class="card-title"> Quiz Details</h6>

                    <form action="<?php echo e(route('quiz.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <label for="exampleInputUsername2" class="col-sm-3 col-form-label">NAME</label>
                            <div class="col-sm-9">
                                <input
                                 name="name"
                                 id="checkchar"
                                type="text" class="form-control" placeholder="Enter Quiz Name...">
                            </div>
                        </div>


                        <div class="row mb-3">
                            <label for="exampleInputUsername2" class="col-sm-3 col-form-label">Instructions</label>
                            <textarea name="instructions" class="form-control" name="tinymce" id="simpleMdeExample" rows="10"></textarea>
                        </div>


                        <div class="row mb-3">
                            <label for="exampleInputUsername2" class="col-sm-3 col-form-label">Image</label>
                            <div class="col-sm-9">
                                <input name="image" type="file" class="form-control"
                                    placeholder="Enter Category Name...">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="exampleInputUsername2" class="col-sm-3 col-form-label">Category</label>
                            <div class="col-sm-9">
                                <select name="category" class="form-select">

                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item['name']); ?>"><?php echo e($item['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-6">
                                <label for="exampleInputUsername2" class="col-sm-3 col-form-label">COINS</label>
                                <div class="col-sm-9">
                                    <input name="coins" type="number" class="form-control" placeholder="Enter Coins...">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="exampleInputUsername2" class="col-sm-3 col-form-label" >Charges Coins</label>
                                <div class="col-sm-12">
                                <input name="charges" type="number" class="form-control" placeholder="Enter Coins..." value="10">
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary me-2 mt-3">Submit</button>

                    </form>

                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-9 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Quiz List</h6>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Image</th>                                    
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th>1</th>
                                        <td><?php echo e($item->name); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset("images/$item->image")); ?>" />
                                        </td>



                                        <td>
                                            <div class="icons-list row"  >
                                                <div

                                                onclick="AddData('<?php echo e(route('que.index', [$item->name])); ?>')"
                                                class="col-md-4 col-sm-12 bg-transparent justify-content-center"> <i
                                                        data-feather="plus-square"></i>
                                            </div>
                                                <div
                                                onclick="EditQuiz('<?php echo e(route('quiz.edit.index', [$item->id])); ?>')"
                                                class="col-md-4 col-sm-12 bg-transparent justify-content-center"
                                                    data-bs-toggle="modal" id="modalBTN" data-bs-target="#editmodal"> <i
                                                        data-feather="edit"></i> </div>
                                                <div
                                                onclick="DeleteData('<?php echo e(route('quiz.delete', [$item->id])); ?>')"
                                                    class="col-md-4  col-sm-12 bg-transparent justify-content-center ">
                                                    <i data-feather="x"></i>
                                                </div>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/simplemde/simplemde.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('assets/js/dashboard.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/datepicker.js')); ?>"></script>

    <script>
        $(function() {
            'use strict';

            /* editor*/
            if ($("#simpleMdeExample").length) {
                var simplemde = new SimpleMDE({
                    toolbar: ["bold", "italic", "heading", "|", "unordered-list", "ordered-list", "|", "preview","fullscreen"],
                    element: $("#simpleMdeExample")[0]
                });
            }

        });

        function DeleteData(url) {

            let text = "Are you sure to delete this record? \nEither OK or Cancel.";
            if (confirm(text) == true) {


                console.log(url);

                let token = document.querySelector('meta[name="csrf-token"]').content;
                let xhr = new XMLHttpRequest();

                xhr.open("POST", url, true);

                xhr.setRequestHeader('X-CSRF-TOKEN', token);

                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        const data = JSON.parse(this.responseText);
                        location.reload();
                    }
                };
                xhr.send();



            }
        }
        function EditQuiz(url) {
            window.location.href = url;
        }
        function DeleteData(url) {
            if (confirm("Press a button!") == true) {
                    window.location.href = url;
                } else {

            }
        }
        function AddData(url) {
            window.location.href = url;
        }
        const eventTarget = document.querySelector('#checkchar');
        const name = document.querySelector('#name');
        if(typeof eventTarget !== undefined){
            eventTarget.addEventListener("keydown", FilterTitle);
        }

        if(typeof name !== undefined){
            name.addEventListener("keydown", FilterTitle);
        }
            function FilterTitle(e) {
                console.log( e.target.value);
                const str = e.target.value;
                const noSpecialCharacters = str.replace(/[^a-zA-Z0-9 ]/g, '');
                e.target.value = noSpecialCharacters;

        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\code\MERN-QUIZ\abhishek-quiz\backend\resources\views/admin/quiz.blade.php ENDPATH**/ ?>