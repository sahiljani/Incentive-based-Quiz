<footer class="footer border-top">
  <div class="container d-flex flex-column flex-md-row align-items-center justify-content-between py-3 small">
    <p class="text-muted mb-1 mb-md-0">Copyright © 2022 <a href="https://www.nobleui.com" target="_blank">NobleUI</a>.</p>
    <p class="text-muted">Handcrafted With <i class="mb-1 text-primary ms-1 icon-sm" data-feather="heart"></i></p>
  </div>
</footer><?php /**PATH R:\code\MERN-QUIZ\abhishek-quiz\backend\resources\views/layout/footer.blade.php ENDPATH**/ ?>